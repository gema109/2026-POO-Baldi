
package model;
import javax.swing.JOptionPane;

public class Imc{
    private double a;
    private double b;

    /**
     * @return the a
     */
    public double getA() {
        return a;
    }

    /**
     * @param a the a to set
     */
    public void setA(double a) {
        this.a = a;
    }

    /**
     * @return the b
     */
    public double getB() {
        return b;
    }

    /**
     * @param b the b to set
     */
    public void setB(double b) {
        this.b = b;
    }
    
    public void Calcular(){
        double c;
        a = a * a;
        c = b/a;
        JOptionPane.showMessageDialog(null, "Seu Indice De Massa Corporal É:" + c);
    }

}
