
package model;
import javax.swing.JOptionPane;

public class SegundoG {

    /**
     * @param c the c to set
     */
    public void setC(double c) {
        this.c = c;
    }
    private double a;
    private double b;
    private double c;
    double d;
    double r;

    public void Calc(){
        if(a == 0){
            JOptionPane.showMessageDialog(null, "Digite um Valor de 'A' Valido");
        }else{
            d = (b * b)-4*a*c;
            r = Math.sqrt(d);
            double x1 = (-b+r)/(2*a);
            double x2 = (-b-r)/(2*a);
            JOptionPane.showMessageDialog(null, "A Raiz x1 É: " + x1 + "\n" + "A Raiz x2 É: " + x2);
        }
    }
    /**
     * @return the a
     */
    public double getA() {
        return a;
    }

    /**
     * @param a the a to set
     */
    public void setA(double a) {
        this.a = a;
    }

    /**
     * @return the b
     */
    public double getB() {
        return b;
    }

    /**
     * @param b the b to set
     */
    public void setB(double b) {
        this.b = b;
    }

    /**
     * @return the c
     */
    public double getC() {
        return c;
    }

    /**
     * @param c the c to set
     */
}
