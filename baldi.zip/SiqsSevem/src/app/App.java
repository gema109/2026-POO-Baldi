
package app;
import view.Tela;

public class App {

    public static void main(String[] args) {
        Tela t = new Tela();
        t.setVisible(true);
    }
    
}
